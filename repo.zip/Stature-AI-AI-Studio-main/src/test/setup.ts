// This file is automatically run before each test.
// It extends the `expect` global with additional matchers from jest-dom,
// giving you helpful assertions for testing DOM nodes.
// learn more: https://github.com/testing-library/jest-dom
import "@testing-library/jest-dom";
